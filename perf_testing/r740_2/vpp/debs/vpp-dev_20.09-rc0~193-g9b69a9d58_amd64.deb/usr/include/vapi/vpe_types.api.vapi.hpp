#ifndef __included_hpp_vpe_types_api_json
#define __included_hpp_vpe_types_api_json

#include <vapi/vapi.hpp>
#include <vapi/vpe_types.api.vapi.h>

namespace vapi {

}
#endif
